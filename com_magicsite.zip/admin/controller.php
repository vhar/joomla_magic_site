<?php

defined('_JEXEC') or exit();

class MagicSiteController extends JControllerLegacy
{
  protected $default_view = 'magicsite';
}
