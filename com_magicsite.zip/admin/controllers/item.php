<?php

defined('_JEXEC') or exit();

class MagicSiteControllerItem extends JControllerForm
{
  protected $view_list = 'magicsite';
}
